import { Router } from "express";
import { db, plansTable, planAttendeesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

// ─── GET /api/plans ──────────────────────────────────────────────────────────
// Devuelve todos los planes de la base de datos.
router.get("/plans", async (_req, res) => {
  try {
    const plans = await db.select().from(plansTable);
    // Serializamos el id como string para que coincida con el tipo Plan del frontend
    const result = plans.map((p) => ({
      ...p,
      id: String(p.id),
    }));
    res.json(result);
  } catch (err) {
    console.error("[GET /api/plans] Error:", err);
    res.status(500).json({ error: "Error al obtener los planes" });
  }
});

// ─── POST /api/join ───────────────────────────────────────────────────────────
// Registra al usuario en un plan y descuenta 1 cupo disponible.
router.post("/join", async (req, res) => {
  const { userId, planId } = req.body as { userId: string; planId: string };

  if (!userId || !planId) {
    res.status(400).json({ error: "userId y planId son requeridos" });
    return;
  }

  const planIdNum = Number(planId);
  const userIdNum = Number(userId);

  if (isNaN(planIdNum) || isNaN(userIdNum)) {
    res.status(400).json({ error: "userId y planId deben ser números válidos" });
    return;
  }

  try {
    await db.transaction(async (tx) => {
      // Verificar que el plan existe y tiene cupos
      const [plan] = await tx
        .select()
        .from(plansTable)
        .where(eq(plansTable.id, planIdNum));

      if (!plan) {
        throw new Error("Plan no encontrado");
      }

      if (plan.availableCupos <= 0) {
        throw new Error("No hay cupos disponibles para este plan");
      }

      // Descontar 1 cupo
      await tx
        .update(plansTable)
        .set({ availableCupos: plan.availableCupos - 1 })
        .where(eq(plansTable.id, planIdNum));

      // Registrar al asistente (upsert manual: ignorar duplicados)
      await tx
        .insert(planAttendeesTable)
        .values({ planId: planIdNum, userId: userIdNum })
        .onConflictDoNothing();
    });

    res.json({ success: true });
  } catch (err: any) {
    console.error("[POST /api/join] Error:", err);
    const status = err.message?.includes("no encontrado") || err.message?.includes("disponibles")
      ? 400
      : 500;
    res.status(status).json({ error: err.message || "Error al unirse al plan" });
  }
});

// ─── GET /api/healthz ─────────────────────────────────────────────────────────
router.get("/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

export default router;
