{ pkgs, ... }: {
  channel = "stable-24.05";

  packages = [
    pkgs.nodejs_22
    pkgs.pnpm
  ];

  env = {};

  idx = {
    extensions = [];

    previews = {
      enable = true;
      previews = {
        web = {
          command = ["pnpm" "--filter" "@workspace/vinku" "run" "dev"];
          manager = "web";
          env = {
            PORT = "$PORT";
            BASE_PATH = "/";
          };
        };
      };
    };

    workspace = {
      onCreate = {
        install = "pnpm install";
      };
      onStart = {
        start-backend = "pnpm --filter @workspace/api-server run dev";
      };
    };
  };
}
