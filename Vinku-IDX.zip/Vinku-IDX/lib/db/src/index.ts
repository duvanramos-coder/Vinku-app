import { config } from "dotenv";
import { fileURLToPath } from "url";
import { dirname, resolve } from "path";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "./schema/index.js";

// Carga .env desde la raíz del proyecto sin importar desde dónde se ejecute
const __dirname = dirname(fileURLToPath(import.meta.url));
// lib/db/src/ → lib/db/ → lib/ → raíz del proyecto
config({ path: resolve(__dirname, "../../../.env"), override: false });

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error(
    "DATABASE_URL no está definida. Verifica que el archivo .env esté en la raíz del proyecto."
  );
}

const client = postgres(connectionString, {
  ssl: "require",
  max: 5,
  idle_timeout: 20,
  connect_timeout: 10,
});

export const db = drizzle(client, { schema });
export * from "./schema/index.js";
